const fs = require('fs');
const path = require('path');

async function runFullAudit() {
  console.log('=== AUDITORIA COMPLETA DE FUNCIONAMIENTO EWUARSOFT ===\n');

  // 1. Verificación de archivos clave
  console.log('1. Verificando estructura de archivos...');
  const files = [
    'src/server.js',
    'src/app.js',
    'src/config/database.js',
    'src/services/authService.js',
    'src/services/productService.js',
    'src/services/inventoryService.js',
    'src/services/salesService.js',
    'src/services/catalogService.js',
    'src/services/reportService.js',
    'public/index.html',
    'public/css/style.css',
    'public/js/api.js',
    'public/js/app.js',
    '../frontend/index.html',
    '../frontend/css/style.css',
    '../frontend/js/api.js',
    '../frontend/js/app.js'
  ];

  for (const f of files) {
    const fullPath = path.join(__dirname, f);
    if (!fs.existsSync(fullPath)) {
      throw new Error('Falta archivo requerido: ' + f);
    }
  }
  console.log('✔ Todos los archivos existen en las rutas correctas.\n');

  // 2. Verificación de Base de Datos MySQL
  console.log('2. Verificando conexion y tablas MySQL (ewarsoft)...');
  const pool = require('./src/config/database');
  const [tables] = await pool.query('SHOW TABLES');
  const tableNames = tables.map(t => Object.values(t)[0]);
  console.log('Tablas detectadas en MySQL:', tableNames);
  
  const requiredTables = ['categories', 'suppliers', 'products', 'sales', 'sale_items', 'inventory_movements', 'users'];
  for (const rt of requiredTables) {
    if (!tableNames.includes(rt)) {
      throw new Error('Falta tabla obligatoria: ' + rt);
    }
  }
  console.log('✔ Las 7 tablas requeridas estan presentes y operativas en MySQL.\n');

  // 3. Verificación de API HTTP
  console.log('3. Ejecutando bateria de pruebas a la API REST (http://localhost:3000)...');
  const BASE = 'http://localhost:3000';

  // 3.1 Health
  const health = await fetch(BASE + '/health').then(r => r.json());
  console.log('✔ /health:', health.message);

  // 3.2 Frontend estático
  const html = await fetch(BASE + '/').then(r => r.text());
  console.log('✔ Frontend index.html servido por Express (' + html.length + ' bytes)');

  // 3.3 Auth: Usuario no existe (404)
  const nonUser = await fetch(BASE + '/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'inexistente_' + Date.now() + '@test.com', password: '123' })
  });
  const nonUserData = await nonUser.json();
  if (nonUser.status === 404 && nonUserData.error && nonUserData.error.includes('no existe')) {
    console.log('✔ Auth (Usuario no existe): Retorna HTTP 404 -> "' + nonUserData.error + '"');
  } else {
    throw new Error('Fallo en test usuario no existe');
  }

  // 3.4 Auth: Contraseña errónea (401)
  const badPass = await fetch(BASE + '/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'admin@lafarra.com', password: 'password_incorrecta' })
  });
  const badPassData = await badPass.json();
  if (badPass.status === 401 && badPassData.error && badPassData.error.includes('incorrecta')) {
    console.log('✔ Auth (Contrasena erronea): Retorna HTTP 401 -> "' + badPassData.error + '"');
  } else {
    throw new Error('Fallo en test contrasena incorrecta');
  }

  // 3.5 Auth: Login Exitoso
  const loginOk = await fetch(BASE + '/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'admin@lafarra.com', password: 'admin123' })
  }).then(r => r.json());
  console.log('✔ Auth (Login exitoso): Token recibido para', loginOk.data.user.name, '(' + loginOk.data.user.role + ')');

  // 3.6 Categorías
  const cats = await fetch(BASE + '/api/categories/list', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  }).then(r => r.json());
  console.log('✔ Categorias consultadas: ' + cats.data.length + ' encontradas');

  // 3.7 Proveedores
  const sups = await fetch(BASE + '/api/suppliers/list', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  }).then(r => r.json());
  console.log('✔ Proveedores consultados: ' + sups.data.length + ' encontrados');

  // 3.8 Productos
  const prods = await fetch(BASE + '/api/products/list', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ include_inactive: true })
  }).then(r => r.json());
  console.log('✔ Productos consultados: ' + prods.data.length + ' productos en base de datos');

  // 3.9 Movimientos de inventario
  const movs = await fetch(BASE + '/api/inventory/movements', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  }).then(r => r.json());
  console.log('✔ Historial de movimientos: ' + movs.data.length + ' registros en MySQL');

  // 3.10 Reporte de ventas
  const sales = await fetch(BASE + '/api/reports/sales', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  }).then(r => r.json());
  console.log('✔ Reporte de ventas: ' + sales.data.length + ' lineas de venta registradas');

  console.log('\n======================================================');
  console.log('>>> TODOS LOS CODIGOS Y MODULOS ESTAN 100% FUNCIONALES <<<');
  console.log('======================================================');
  process.exit(0);
}

runFullAudit().catch(err => {
  console.error('\n❌ ERROR EN LA AUDITORIA:', err.message);
  process.exit(1);
});
